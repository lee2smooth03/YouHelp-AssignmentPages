"use strict"
$(document).ready(function(){
//create an array to capture each new box
var evryBOX = [];
var clickCT = 0;


  	$(function(){
        $(".draggable").draggable();
        $(".droppable").droppable();
    });
    
	// $(".resting").on("mouseover", function(){
 
    // 	$("#sidebar").removeClass("slideClass-OUT");
    //     $("#sidebar").addClass("slideClass-IN");
 
 	// }); 
 
    // $(".resting").on("mouseout", function(){
 
    //     $("#sidebar").removeClass("slideClass-IN");
    //     $("#sidebar").addClass("slideClass-OUT");
 
    // });
    //every time the user clicks this button...

    $("#boxpop").on("click", function(){
        clickCT++;

        var boxID = "box" + clickCT;
        //(for later) ...if the window space is unoccupied...
        //place a box element inside of the display window
        console.log("user just added a box!");

        var newBox = $("<div>");
        newBox.html("Drag Me");

        newBox.attr("class", "dragme draggable ui-widget-content");
        newBox.attr("id", boxID);

        console.log(clickCT);

        $(".window").append(newBox);

        //make the elemnt draggable
    });

    // $("#boxpop").on("click", function()
    //     {
    //         console.log("I'm Hit")
    //     });
});